<?php
// if (function_exists('acf_add_options_page')) {

//     acf_add_options_page(
//         array(
//             'page_title' => __('Flitshop Integration'),
//             'menu_title' => __('Flitshop Integration'),
//             'menu_slug' => 'flitshop-integration',
//             'capability' => 'edit_posts',
//             'position' => '100',
//             'redirect' => false
//         )
//     );

//     acf_add_options_sub_page(
//         array(
//             'page_title'  => __('Configurações - Flitshop'),
//             'menu_title'  => __('Configurações'),
//             'parent_slug' => 'flitshop-integration',
//             'menu_slug' => 'flitshop-int-configs'
//         )
//     );

//     acf_add_options_sub_page(
//         array(
//             'page_title'  => __('Instruções - Flitshop'),
//             'menu_title'  => __('Instruções'),
//             'parent_slug' => 'flitshop-integration',
//             'menu_slug' => 'flitshop-int-instru'
//         )
//     );
// }
